function Kff = questao1a(R, Kt, J, b)
% Use as variaveis R, Kt, J e b para definir a sua resposta.
% Talvez voce nao precise de todas as variaveis para definir sua resposta.
% Definir Kff, que eh retornado pela funcao.

% Kff = ...
Kff = Kt + R*b/Kt;
end
