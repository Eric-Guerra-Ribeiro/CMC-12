function tau = questao1a()
% Retorne a constante de tempo do circuito RLC. Use SI.
% V = 5;
R = 10e3;
C = 1e-6;
% tau = ...
tau = R*C;
end