function alternativa = questao1()
% De sua resposta como um caractere atraves da variavel retornada
% alternativa. Ou seja, atribua uma das seguintes possibilidades:
% alternativa = 'a';
% alternativa = 'b';
% alternativa = 'c';
% alternativa = 'd';
% alternativa = 'e';

alternativa = 'c';

end